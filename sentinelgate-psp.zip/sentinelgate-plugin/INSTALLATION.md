# Installation Guide - WooCommerce Plugin

## Quick Start (5 minutes)

### Step 1: Upload to WordPress

**Via WordPress Admin:**

1. Go to Plugins → Add New → Upload Plugin
2. Choose the ZIP file
3. Click Install Now
4. Activate

**Via FTP:**

```bash
# Upload to your server
cd /path/to/wordpress/wp-content/plugins/
unzip sentinelgate-payments.zip
```

### Step 2: Configure

1. WooCommerce → Settings → Payments
2. Enable SentinelGate
3. Add credentials (see below)

### Step 3: setup

1. API Key: "sk_live_something"
2. API Secret: sk_live_something
3. Webhook Secret: "whsec_something"

## Troubleshooting

### Plugin not showing in checkout

- Ensure WooCommerce is active
- Check plugin is enabled in settings
- Verify currency is supported (USD)

### Need Help?

Email: Support@SentinelGAte.Biz
Phone: +1 418 476 0308
