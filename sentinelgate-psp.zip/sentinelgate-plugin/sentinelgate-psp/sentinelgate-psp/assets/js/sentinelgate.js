(function ($) {
    'use strict';
    var SG_TOKEN_RECEIVED = false;
    window.addEventListener('message', function (event) {
        if (!event.data || typeof event.data !== 'object') return;
        if (event.data.type === 'sentinelgate_token' && event.data.token) {
            SG_TOKEN_RECEIVED = true;
            $('#sg_token').val(event.data.token);
            console.log('[SentinelGate] Token received.');
            $('form.checkout').trigger('submit');
        }
        if (event.data.type === 'sentinelgate_token_error') {
            SG_TOKEN_RECEIVED = false;
            var msg = event.data.message || 'Tokenization failed. Please try again.';
            console.error('[SentinelGate] Token error:', msg);
            $('.woocommerce-error, .woocommerce-message').remove();
            $('form.checkout').prepend('<div class="woocommerce-error" role="alert">' + msg + '</div>');
            $('html, body').animate({ scrollTop: $('form.checkout').offset().top - 100 }, 500);
        }
    });
    $(document.body).on('checkout_place_order_sentinelgate_psp', function () {
        var $iframe = $('#sg-token-iframe');
        if ($iframe.length === 0) return true;
        if ($('#sg_token').val()) return true;
        if (!SG_TOKEN_RECEIVED) {
            console.log('[SentinelGate] Requesting token from iframe...');
            var iframeWindow = $iframe[0].contentWindow;
            if (iframeWindow) {
                iframeWindow.postMessage({ type: 'sentinelgate_tokenize' }, '*');
            }
            return false;
        }
        return true;
    });
})(jQuery);
