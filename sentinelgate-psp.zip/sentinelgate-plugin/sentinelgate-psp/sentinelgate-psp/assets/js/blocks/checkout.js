const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { createElement } = window.wp.element;
const { decodeEntities } = window.wp.htmlEntities;
const settings = window.wc.wcSettings.getSetting("sentinelgate_psp_data", {});

const Label = () => {
  return createElement(
    "span",
    null,
    decodeEntities(settings.title || "SentinelGate")
  );
};

const Content = () => {
  return createElement(
    "div",
    null,
    decodeEntities(
      settings.description || "You will be redirected to complete payment."
    )
  );
};

registerPaymentMethod({
  name: "sentinelgate_psp",
  label: createElement(Label, null),
  content: createElement(Content, null),
  edit: createElement(Content, null),
  canMakePayment: () => true,
  ariaLabel: "SentinelGate Payment",
  supports: {
    features: settings.supports || ["products"],
  },
});
