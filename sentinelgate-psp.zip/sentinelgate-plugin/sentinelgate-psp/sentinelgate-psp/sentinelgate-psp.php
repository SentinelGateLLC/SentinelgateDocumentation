<?php

/**
 * Plugin Name: SentinelGate PSP for WooCommerce
 * Plugin URI:  https://sentinelgate.biz
 * Description: SentinelGate Payment Service Provider — supports Direct API, Redirect Hosted Checkout, and iFrame Token modes with HMAC-verified webhooks.
 * Version:     1.0.0
 * Author:      Whyte AG Group
 * Author URI:  https://sentinelgate.biz
 * License:     GPL-2.0+
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * WC requires at least: 6.0
 * WC tested up to: 10.5
 */

defined('ABSPATH') || exit;

define('SG_PSP_VERSION', '1.0.0');
define('SG_PSP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SG_PSP_PLUGIN_URL', plugin_dir_url(__FILE__));

/**
 * Check WooCommerce dependency
 */
function sg_psp_check_woocommerce()
{
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            echo '<div class="error"><p><strong>SentinelGate PSP</strong> requires WooCommerce to be installed and active.</p></div>';
        });
        return false;
    }
    return true;
}

/**
 * Initialize gateway after plugins loaded
 */
add_action('plugins_loaded', function () {
    if (!sg_psp_check_woocommerce()) return;

    require_once SG_PSP_PLUGIN_DIR . 'includes/class-sentinelgatepsp-gateway.php';

    // Register gateway
    add_filter('woocommerce_payment_gateways', function ($gateways) {
        $gateways[] = 'WC_Gateway_SentinelGate_PSP';
        return $gateways;
    });
}, 10);

/**
 * Enqueue frontend JS for iFrame mode
 */
add_action('wp_enqueue_scripts', function () {
    if (!is_checkout()) return;
    wp_enqueue_script(
        'sentinelgate-psp-js',
        SG_PSP_PLUGIN_URL . 'assets/js/sentinelgate.js',
        ['jquery'],
        SG_PSP_VERSION,
        true
    );
});
/**
 * Register Blocks support
 */
add_action('woocommerce_blocks_loaded', function () {

    if (!class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
        return;
    }

    require_once SG_PSP_PLUGIN_DIR . 'includes/class-sentinelgatepsp-blocks.php';

    add_action(
        'woocommerce_blocks_payment_method_type_registration',
        function ($payment_method_registry) {
            $payment_method_registry->register(
                new WC_Gateway_SentinelGate_PSP_Blocks()
            );
        }
    );
});

/**
 * Add settings link on plugins page
 */
add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
    $settings_url = admin_url('admin.php?page=wc-settings&tab=checkout&section=sentinelgate_psp');
    array_unshift($links, '<a href="' . esc_url($settings_url) . '">Settings</a>');
    return $links;
});
