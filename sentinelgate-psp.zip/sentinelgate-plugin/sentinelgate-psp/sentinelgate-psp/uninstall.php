<?php
/**
 * SentinelGate PSP Uninstall
 *
 * Cleans up plugin options when uninstalled via WordPress admin.
 */

// Exit if not called by WordPress uninstall
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Remove gateway settings
delete_option('woocommerce_sentinelgate_psp_settings');

// Remove order meta (optional — uncomment if desired)
// global $wpdb;
// $wpdb->delete($wpdb->postmeta, ['meta_key' => '_sg_transaction_id']);
