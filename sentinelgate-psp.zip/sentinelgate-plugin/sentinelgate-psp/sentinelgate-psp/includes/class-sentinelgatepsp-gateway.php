<?php
defined('ABSPATH') || exit;

class WC_Gateway_SentinelGate_PSP extends WC_Payment_Gateway {

    /** @var string API base URL */
    private $api_base_url;
    /** @var string API key */
    private $api_key;
    /** @var string API secret */
    private $api_secret;
    /** @var string Webhook secret for HMAC verification */
    private $webhook_secret;
    /** @var string Integration mode: direct|redirect|iframe */
    private $mode;
    /** @var string iFrame URL for tokenization */
    private $iframe_url;
    /** @var bool Debug logging */
    private $debug_mode;

    public function __construct() {
        $this->id                 = 'sentinelgate_psp';
        $this->icon               = '';
        $this->has_fields         = true;
        $this->method_title       = 'SentinelGate PSP';
        $this->method_description = 'Accept payments via SentinelGate — Direct API, Redirect Hosted Checkout, or iFrame Token modes.';
        $this->supports           = ['products', 'refunds'];

        $this->init_form_fields();
        $this->init_settings();

        $this->title          = $this->get_option('title', 'Pay with SentinelGate');
        $this->description    = $this->get_option('description', 'Secure payment powered by SentinelGate.');
        $this->enabled        = $this->get_option('enabled');
        $this->api_base_url   = rtrim($this->get_option('api_base_url', 'https://sentinelgate.biz'), '/');
        $this->api_key        = $this->get_option('api_key');
        $this->api_secret     = $this->get_option('api_secret');
        $this->webhook_secret = $this->get_option('webhook_secret');
        $this->mode           = $this->get_option('mode', 'redirect');
        $this->iframe_url     = $this->get_option('iframe_url');
        $this->debug_mode     = $this->get_option('debug') === 'yes';

        // Save admin settings
        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);

        // Register webhook callback
        add_action('woocommerce_api_sentinelgate_callback', [$this, 'handle_webhook']);
    }

    /* ───────────────────────────────────────────────
     *  ADMIN SETTINGS
     * ─────────────────────────────────────────────── */

    public function init_form_fields() {
        $this->form_fields = [
            'enabled' => [
                'title'   => 'Enable/Disable',
                'type'    => 'checkbox',
                'label'   => 'Enable SentinelGate PSP',
                'default' => 'no',
            ],
            'title' => [
                'title'       => 'Title',
                'type'        => 'text',
                'description' => 'Shown to customer at checkout.',
                'default'     => 'Pay with SentinelGate',
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => 'Description',
                'type'        => 'textarea',
                'description' => 'Shown below the title at checkout.',
                'default'     => 'Secure payment powered by SentinelGate.',
                'desc_tip'    => true,
            ],
            'mode' => [
                'title'       => 'Integration Mode',
                'type'        => 'select',
                'description' => 'How the customer pays. Redirect is recommended.',
                'default'     => 'redirect',
                'options'     => [
                    'direct'   => 'Mode A — Direct API (PCI required)',
                    'redirect' => 'Mode B — Redirect Hosted Checkout',
                    'iframe'   => 'Mode C — iFrame Token',
                ],
                'desc_tip'    => true,
            ],
            'api_base_url' => [
                'title'       => 'API Base URL',
                'type'        => 'text',
                'description' => 'SentinelGate API endpoint.',
                'default'     => 'https://sentinelgate.biz',
                'desc_tip'    => true,
            ],
            'api_key' => [
                'title'       => 'API Key',
                'type'        => 'password',
                'description' => 'Your SentinelGate API key.',
                'desc_tip'    => true,
            ],
            'api_secret' => [
                'title'       => 'API Secret',
                'type'        => 'password',
                'description' => 'Your SentinelGate API secret.',
                'desc_tip'    => true,
            ],
            'webhook_secret' => [
                'title'       => 'Webhook Secret',
                'type'        => 'password',
                'description' => 'Secret for HMAC-SHA256 webhook signature verification.',
                'desc_tip'    => true,
            ],
            'iframe_url' => [
                'title'       => 'iFrame Tokenization URL',
                'type'        => 'text',
                'description' => 'Required for iFrame Token mode only.',
                'default'     => '',
                'desc_tip'    => true,
            ],
            'debug' => [
                'title'   => 'Debug Log',
                'type'    => 'checkbox',
                'label'   => 'Enable debug logging',
                'default' => 'no',
                'description' => 'Logs to WooCommerce → Status → Logs (sentinelgate-psp).',
            ],
        ];
    }

    /* ───────────────────────────────────────────────
     *  CHECKOUT PAYMENT FIELDS
     * ─────────────────────────────────────────────── */

    public function payment_fields() {
        if ($this->description) {
            echo wpautop(wp_kses_post($this->description));
        }

        switch ($this->mode) {

            // MODE A: Direct — card fields on merchant page
            case 'direct':
                ?>
                <fieldset id="wc-<?php echo esc_attr($this->id); ?>-cc-form" class="wc-credit-card-form wc-payment-form">
                    <p class="form-row form-row-wide">
                        <label for="sg-card-number">Card Number <span class="required">*</span></label>
                        <input type="text" id="sg-card-number" name="sg_card_number" class="input-text" autocomplete="cc-number" placeholder="•••• •••• •••• ••••" maxlength="19" required />
                    </p>
                    <p class="form-row form-row-first">
                        <label for="sg-card-expiry">Expiry (MM/YY) <span class="required">*</span></label>
                        <input type="text" id="sg-card-expiry" name="sg_card_expiry" class="input-text" autocomplete="cc-exp" placeholder="MM/YY" maxlength="5" required />
                    </p>
                    <p class="form-row form-row-last">
                        <label for="sg-card-cvv">CVV <span class="required">*</span></label>
                        <input type="text" id="sg-card-cvv" name="sg_card_cvv" class="input-text" autocomplete="cc-csc" placeholder="•••" maxlength="4" required />
                    </p>
                    <div class="clear"></div>
                </fieldset>
                <?php
                break;

            // MODE C: iFrame — tokenization iframe
            case 'iframe':
                $iframe_src = esc_url($this->iframe_url);
                if ($iframe_src) {
                    ?>
                    <div id="sg-iframe-container" style="min-height:320px;border:1px solid #ddd;border-radius:4px;overflow:hidden;margin-bottom:10px;">
                        <iframe
                            id="sg-token-iframe"
                            src="<?php echo $iframe_src; ?>"
                            style="width:100%;height:320px;border:none;"
                            title="Secure Payment"
                        ></iframe>
                    </div>
                    <input type="hidden" id="sg_token" name="sg_token" value="" />
                    <noscript><p style="color:red;">JavaScript is required for secure payments.</p></noscript>
                    <?php
                } else {
                    echo '<p style="color:red;">iFrame URL not configured. Contact store administrator.</p>';
                }
                break;

            // MODE B: Redirect — no fields needed, customer goes to hosted page
            case 'redirect':
            default:
                echo '<p>' . esc_html__('You will be redirected to a secure payment page to complete your order.', 'sentinelgate-psp') . '</p>';
                break;
        }
    }

    /* ───────────────────────────────────────────────
     *  FIELD VALIDATION
     * ─────────────────────────────────────────────── */

    public function validate_fields() {
        switch ($this->mode) {
            case 'direct':
                $card = sanitize_text_field($_POST['sg_card_number'] ?? '');
                $exp  = sanitize_text_field($_POST['sg_card_expiry'] ?? '');
                $cvv  = sanitize_text_field($_POST['sg_card_cvv'] ?? '');
                if (empty($card) || strlen(preg_replace('/\D/', '', $card)) < 13) {
                    wc_add_notice('Please enter a valid card number.', 'error');
                    return false;
                }
                if (empty($exp) || !preg_match('/^\d{2}\/\d{2}$/', $exp)) {
                    wc_add_notice('Please enter a valid expiry date (MM/YY).', 'error');
                    return false;
                }
                if (empty($cvv) || !preg_match('/^\d{3,4}$/', $cvv)) {
                    wc_add_notice('Please enter a valid CVV.', 'error');
                    return false;
                }
                return true;

            case 'iframe':
                $token = sanitize_text_field($_POST['sg_token'] ?? '');
                if (empty($token)) {
                    wc_add_notice('Payment token was not received. Please try again.', 'error');
                    return false;
                }
                return true;

            case 'redirect':
            default:
                return true;
        }
    }

    /* ───────────────────────────────────────────────
     *  PROCESS PAYMENT (3 MODES)
     * ─────────────────────────────────────────────── */

    public function process_payment($order_id) {
        $order = wc_get_order($order_id);

        switch ($this->mode) {

            /* ── MODE A: Direct API charge ── */
            case 'direct':
                return $this->process_direct($order);

            /* ── MODE B: Redirect to hosted checkout ── */
            case 'redirect':
                return $this->process_redirect($order);

            /* ── MODE C: iFrame token charge ── */
            case 'iframe':
                return $this->process_iframe($order);

            default:
                wc_add_notice('Invalid payment mode configured.', 'error');
                return ['result' => 'fail'];
        }
    }

    /* ── MODE A: Direct ── */
    private function process_direct($order) {
        $card_number = preg_replace('/\D/', '', sanitize_text_field($_POST['sg_card_number']));
        $card_expiry = sanitize_text_field($_POST['sg_card_expiry']);
        $card_cvv    = sanitize_text_field($_POST['sg_card_cvv']);

        list($exp_month, $exp_year) = explode('/', $card_expiry);

        $payload = [
            'amount'        => number_format($order->get_total(), 2, '.', ''),
            'currency'      => $order->get_currency(),
            'order_id'      => $order->get_id(),
            'description'   => sprintf('Order #%s from %s', $order->get_id(), get_bloginfo('name')),
            'customer_email' => $order->get_billing_email(),
            'card' => [
                'number'    => $card_number,
                'exp_month' => trim($exp_month),
                'exp_year'  => '20' . trim($exp_year),
                'cvv'       => $card_cvv,
            ],
            'callback_url'  => home_url('/wc-api/sentinelgate_callback/'),
        ];

        $result = $this->api_post('/v1/charge', $payload);

        if (is_wp_error($result)) {
            wc_add_notice('Payment failed: ' . $result->get_error_message(), 'error');
            return ['result' => 'fail'];
        }

        return $this->handle_charge_response($order, $result);
    }

    /* ── MODE B: Redirect ── */
    private function process_redirect($order) {
        $payload = [
            'amount'        => number_format($order->get_total(), 2, '.', ''),
            'currency'      => $order->get_currency(),
            'order_id'      => $order->get_id(),
            'description'   => sprintf('Order #%s from %s', $order->get_id(), get_bloginfo('name')),
            'customer_email' => $order->get_billing_email(),
            'customer_name'  => $order->get_formatted_billing_full_name(),
            'callback_url'  => home_url('/wc-api/sentinelgate_callback/'),
            'return_url'    => $this->get_return_url($order),
            'cancel_url'    => wc_get_checkout_url(),
        ];

        $result = $this->api_post('/v1/hosted/create', $payload);

        if (is_wp_error($result)) {
            wc_add_notice('Payment failed: ' . $result->get_error_message(), 'error');
            return ['result' => 'fail'];
        }

        $redirect_url = $result['redirect_url'] ?? $result['hosted_url'] ?? $result['url'] ?? '';

        if (empty($redirect_url)) {
            $this->log('Redirect mode: no redirect_url in response: ' . wp_json_encode($result));
            wc_add_notice('Payment gateway did not return a redirect URL.', 'error');
            return ['result' => 'fail'];
        }

        // Store transaction ID
        $txn_id = $result['sentinel_transaction_id'] ?? $result['transaction_id'] ?? '';
        if ($txn_id) {
            $order->update_meta_data('_sg_transaction_id', $txn_id);
        }
        $order->update_status('pending', 'Redirecting to SentinelGate hosted checkout.');
        $order->save();

        return [
            'result'   => 'success',
            'redirect' => $redirect_url,
        ];
    }

    /* ── MODE C: iFrame Token ── */
    private function process_iframe($order) {
        $token = sanitize_text_field($_POST['sg_token']);

        $payload = [
            'amount'        => number_format($order->get_total(), 2, '.', ''),
            'currency'      => $order->get_currency(),
            'order_id'      => $order->get_id(),
            'description'   => sprintf('Order #%s from %s', $order->get_id(), get_bloginfo('name')),
            'customer_email' => $order->get_billing_email(),
            'token'         => $token,
            'callback_url'  => home_url('/wc-api/sentinelgate_callback/'),
        ];

        $result = $this->api_post('/v1/charge', $payload);

        if (is_wp_error($result)) {
            wc_add_notice('Payment failed: ' . $result->get_error_message(), 'error');
            return ['result' => 'fail'];
        }

        return $this->handle_charge_response($order, $result);
    }

    /* ───────────────────────────────────────────────
     *  CHARGE RESPONSE HANDLER (Direct + iFrame)
     * ─────────────────────────────────────────────── */

    private function handle_charge_response($order, $response) {
        $status = strtolower($response['status'] ?? '');
        $txn_id = $response['sentinel_transaction_id'] ?? $response['transaction_id'] ?? '';

        if ($txn_id) {
            $order->update_meta_data('_sg_transaction_id', $txn_id);
            $order->save();
        }

        switch ($status) {
            case 'captured':
            case 'success':
                $order->payment_complete($txn_id);
                $order->add_order_note(sprintf('SentinelGate payment captured. Txn: %s', $txn_id));
                WC()->cart->empty_cart();
                return ['result' => 'success', 'redirect' => $this->get_return_url($order)];

            case 'authorized':
                $order->update_status('on-hold', sprintf('SentinelGate payment authorized. Txn: %s', $txn_id));
                WC()->cart->empty_cart();
                return ['result' => 'success', 'redirect' => $this->get_return_url($order)];

            case 'pending':
                $order->update_status('pending', 'SentinelGate payment pending.');
                WC()->cart->empty_cart();
                return ['result' => 'success', 'redirect' => $this->get_return_url($order)];

            case 'failed':
            default:
                $reason = $response['error_reason'] ?? $response['message'] ?? 'Payment was not successful.';
                $order->update_status('failed', sprintf('SentinelGate payment failed: %s', $reason));
                wc_add_notice('Payment failed: ' . $reason, 'error');
                return ['result' => 'fail'];
        }
    }

    /* ───────────────────────────────────────────────
     *  WEBHOOK HANDLER (HMAC verified)
     * ─────────────────────────────────────────────── */

    public function handle_webhook() {
        $raw_body = file_get_contents('php://input');
        $this->log('Webhook received: ' . $raw_body);

        // Verify HMAC signature
        $signature = $_SERVER['HTTP_X_SG_SIGNATURE'] ?? '';
        if (!$this->verify_hmac($raw_body, $signature)) {
            $this->log('Webhook HMAC verification FAILED.');
            wp_send_json(['status' => 'error', 'message' => 'Invalid signature'], 401);
            return;
        }

        $data = json_decode($raw_body, true);
        if (!$data) {
            wp_send_json(['status' => 'error', 'message' => 'Invalid JSON'], 400);
            return;
        }

        $txn_id   = $data['sentinel_transaction_id'] ?? '';
        $order_id = intval($data['wc_order_id'] ?? 0);
        $status   = strtolower($data['status'] ?? '');
        $reason   = $data['error_reason'] ?? '';

        // Find order by order_id or by stored txn_id
        $order = null;
        if ($order_id) {
            $order = wc_get_order($order_id);
        }
        if (!$order && $txn_id) {
            $orders = wc_get_orders([
                'meta_key'   => '_sg_transaction_id',
                'meta_value' => $txn_id,
                'limit'      => 1,
            ]);
            $order = !empty($orders) ? $orders[0] : null;
        }

        if (!$order) {
            $this->log("Webhook: Order not found. order_id={$order_id}, txn={$txn_id}");
            wp_send_json(['status' => 'error', 'message' => 'Order not found'], 404);
            return;
        }

        // Don't process already completed orders
        if ($order->is_paid()) {
            $this->log("Webhook: Order #{$order->get_id()} already paid, skipping.");
            wp_send_json(['status' => 'ok', 'message' => 'Already processed']);
            return;
        }

        // Update order based on status
        switch ($status) {
            case 'captured':
                $order->payment_complete($txn_id);
                $order->add_order_note(sprintf(
                    'SentinelGate webhook: Payment captured. Txn: %s', $txn_id
                ));
                $this->log("Order #{$order->get_id()} → captured (txn: {$txn_id})");
                break;

            case 'authorized':
                $order->update_status('on-hold', sprintf(
                    'SentinelGate webhook: Payment authorized. Txn: %s', $txn_id
                ));
                $this->log("Order #{$order->get_id()} → authorized");
                break;

            case 'failed':
                $order->update_status('failed', sprintf(
                    'SentinelGate webhook: Payment failed. Reason: %s', $reason
                ));
                $this->log("Order #{$order->get_id()} → failed: {$reason}");
                break;

            default:
                $this->log("Webhook: Unknown status '{$status}' for order #{$order->get_id()}");
                break;
        }

        wp_send_json(['status' => 'ok']);
    }

    /* ───────────────────────────────────────────────
     *  HMAC SIGNATURE VERIFICATION
     * ─────────────────────────────────────────────── */

    private function verify_hmac($raw_body, $signature) {
        if (empty($this->webhook_secret) || empty($signature)) {
            return false;
        }
        $expected = base64_encode(hash_hmac('sha256', $raw_body, $this->webhook_secret, true));
        return hash_equals($expected, $signature);
    }

    /* ───────────────────────────────────────────────
     *  API HELPER
     * ─────────────────────────────────────────────── */

    private function api_post($endpoint, $payload) {
        $url = $this->api_base_url . $endpoint;

        $headers = [
            'Content-Type'   => 'application/json',
            'X-API-Key'      => $this->api_key,
            'X-API-Secret'   => $this->api_secret,
            'X-SG-Source'    => 'woocommerce',
            'X-SG-Version'   => SG_PSP_VERSION,
        ];

        $this->log("API POST {$url}: " . wp_json_encode($payload));

        $response = wp_remote_post($url, [
            'method'  => 'POST',
            'timeout' => 45,
            'headers' => $headers,
            'body'    => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            $this->log('API WP Error: ' . $response->get_error_message());
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        $this->log("API Response [{$code}]: {$body}");

        if ($code < 200 || $code >= 300) {
            $msg = $data['error'] ?? $data['message'] ?? "HTTP {$code}";
            return new WP_Error('sg_api_error', $msg);
        }

        return $data;
    }

    /* ───────────────────────────────────────────────
     *  REFUND SUPPORT
     * ─────────────────────────────────────────────── */

    public function process_refund($order_id, $amount = null, $reason = '') {
        $order  = wc_get_order($order_id);
        $txn_id = $order->get_meta('_sg_transaction_id');

        if (empty($txn_id)) {
            return new WP_Error('no_txn', 'No SentinelGate transaction ID found for this order.');
        }

        $result = $this->api_post('/v1/refund', [
            'sentinel_transaction_id' => $txn_id,
            'amount'                  => number_format($amount, 2, '.', ''),
            'reason'                  => $reason,
        ]);

        if (is_wp_error($result)) {
            return $result;
        }

        $refund_status = strtolower($result['status'] ?? '');
        if (in_array($refund_status, ['refunded', 'success', 'approved'])) {
            $order->add_order_note(sprintf(
                'SentinelGate refund processed: %s %s. Reason: %s',
                $order->get_currency(), $amount, $reason ?: 'N/A'
            ));
            return true;
        }

        return new WP_Error('refund_failed', $result['message'] ?? 'Refund was not successful.');
    }

    /* ───────────────────────────────────────────────
     *  LOGGER
     * ─────────────────────────────────────────────── */
    public function is_available()
    {
        return $this->enabled === 'yes';
    }
    private function log($message) {
        if ($this->debug_mode && function_exists('wc_get_logger')) {
            wc_get_logger()->debug($message, ['source' => 'sentinelgate-psp']);
        }
    }
}
