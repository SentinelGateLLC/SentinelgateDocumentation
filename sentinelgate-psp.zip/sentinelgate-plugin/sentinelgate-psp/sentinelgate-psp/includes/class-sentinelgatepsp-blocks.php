<?php

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

defined('ABSPATH') || exit;

final class WC_Gateway_SentinelGate_PSP_Blocks extends AbstractPaymentMethodType
{

    protected $name = 'sentinelgate_psp';

    public function initialize()
    {
        $this->settings = get_option('woocommerce_sentinelgate_psp_settings', []);
    }

    public function is_active()
    {
        return !empty($this->settings['enabled']) && $this->settings['enabled'] === 'yes';
    }

    public function get_payment_method_script_handles()
    {
        wp_register_script(
            'sentinelgate-psp-blocks',
            SG_PSP_PLUGIN_URL . 'assets/js/blocks/checkout.js',
            ['wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities'],
            SG_PSP_VERSION,
            true
        );

        return ['sentinelgate-psp-blocks'];
    }

    public function get_payment_method_data()
    {
        return [
            'title'       => 'SentinelGate',
            'description' => 'Pay securely using SentinelGate.',
            'supports'    => ['products'],
        ];
    }
}
